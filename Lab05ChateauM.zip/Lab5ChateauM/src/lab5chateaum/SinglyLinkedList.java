package lab5chateaum;

/**
 *
 * @author Chateau M
 */
public class SinglyLinkedList<E> {
    //declare private fields    

    private Node<E> head;
    private Node<E> tail;
    private int numElements;

    /**
     * No-Arg Constructor
     */
    public SinglyLinkedList() {
        head = null;
        tail = null;
        numElements = 0;
    }

    /**
     * prependList method - this method adds a new item into the fruit bag at
     * the beginning of the bag
     *
     * @param newElement
     */
    public void prependList(E newElement) {
        if (head == null) {
            head = new Node<E>(newElement, null);
            tail = head;
        } else {
            head = new Node<E>(newElement, head);
        }
        numElements++;
    }

    /**
     * appendList method - this method adds a car to the car bag at the end of
     * the bag
     *
     * @param newElement
     */
    public void appendList(E newElement) {

        if (tail == null) {
            head = new Node<E>(newElement, null);
            tail = head;
        } else {
            tail.setNext(new Node<E>(newElement, null));
            tail = tail.getNext();
        }
        numElements++;

    }

    /**
     * getSize method - this method gets the size of the bag
     *
     * @return returns size of the bag
     */
    public int getSize() {
        return numElements;
    }

    /**
     * exists method - this method finds if the targeted item exists within the
     * bag
     *
     * @param target the item being targeted for finding
     * @return returns the found item
     */
    public boolean exists(E target) {
        boolean found = false;
        Node<E> cursor = head;
        while (cursor != null && !found) {
            if (cursor.getData().equals(target)) {
                found = true;
            } else {
                cursor = cursor.getNext();
            }

        }
        return found;
    }

    /**
     * countOccurrences method - this method counts how many times the targeted
     * item appears
     *
     * @param target the item targeted to be found
     * @return returns the number of occurrences
     */
    public int countOccurrences(E target) {

        Node<E> cursor = head;
        int countOccurrences = 0;

        while (cursor != null) {

            if (cursor.getData().equals(target)) {
                countOccurrences++;
                cursor = cursor.getNext();
            } else {
                cursor = cursor.getNext();
            }

        }
        return countOccurrences;
    }

    /**
     * remove method - this method removes the targeted item
     *
     * @param target
     * @return
     */
    public boolean remove(E target) {
        Node<E> cursor = head, previous = null;
        boolean found = false;
        while (cursor != null && !found) {
            if (cursor.getData().equals(target)) {
                found = true;
            } else {
                previous = cursor;
                cursor = cursor.getNext();
            }
        }
        if (found && cursor != null) {
            if (previous == null) {
                head = head.getNext();
            } else {
                previous.setNext(cursor.getNext());
            }
            if (tail == cursor) {
                tail = previous;
            }
            numElements--;
        }
        return found;
    }

    /**
     * the iteratorPrototype method "copies" the linked list and passes the
     * copied linked list to a new Lister<E>
     *
     * @return a Lister<E> using a copy of the linked list
     */
    public Lister<E> iterator() {
        // declare variables
        Node headOfListToReturn; // beginning of new "copied" list
        Node cursorOfListToCopy; // active node of list to copy
        Node lastNodeOfListToReturn; // end of new "copied" list

        // establish the copied list
        headOfListToReturn = null;

        if (head != null) {
            // create the head of the new list
            headOfListToReturn = new Node(head.getData(), null);
            // use lastNodeOfListToReturn as a pointer to the last node in the copied list
            lastNodeOfListToReturn = headOfListToReturn;
            // use currentCursor as the pointer to the existing list
            cursorOfListToCopy = head.getNext();
            // if we have a node...
            while (cursorOfListToCopy != null) {
                // create a new node from the end of the new list
                lastNodeOfListToReturn.setNext(new Node(cursorOfListToCopy.getData(), null));
                // move lastNodeOfListToReturn to the new last node
                lastNodeOfListToReturn = lastNodeOfListToReturn.getNext();
                // move the cursorOfListToCopy to the next node
                cursorOfListToCopy = cursorOfListToCopy.getNext();
            }
        }

        return new Lister(headOfListToReturn);
    }

}
