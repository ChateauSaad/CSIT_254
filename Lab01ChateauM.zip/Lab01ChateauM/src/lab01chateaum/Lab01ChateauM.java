package lab01chateaum;

import java.util.Scanner;

/**
 *
 * @author ChateauM 09/07/2023 This main method takes the user input for Song
 * Title, Artist, and Song Length, storing that data and printing back out at
 * the user.
 */
public class Lab01ChateauM {

    public static void main(String[] args) {

        Scanner keyboard = new Scanner(System.in);

        String songTitleEntered;
        String artistEntered;
        int lengthEntered;

        System.out.print("Enter song title: ");
        songTitleEntered = keyboard.nextLine();
        
        System.out.print("Enter Artist: ");
        artistEntered = keyboard.nextLine();
       
        System.out.print("Enter length in seconds: ");
        lengthEntered = keyboard.nextInt();

        Song mySong = new Song(songTitleEntered,
                artistEntered, lengthEntered);
        System.out.println("You Entered: ");
        System.out.println("\nSong title: " + mySong.getSongTitle()
                + "\nArtist: " + mySong.getArtist() + "\nLength(seconds): "
                + mySong.getLengthInSeconds());
    }

}
