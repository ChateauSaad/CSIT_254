package ChateauLab3;

/**
 * StringBag Class for Lab 3
 * @author Michael Main / Stephen T. Brower<stephen.brower@raritanval.edu>
 *         Updated by: Linda Yang
 *         Modified by: Chateau Markos-Saad
 *                         
 */
public class StringBag
{
    private String[] data;
    private int numElements;

    /**
     * Constructor
     * @param initialCapacity  the initial size of the bag 
     *                         
     */
    public StringBag(int initialCapacity)
    {
       data = new String[initialCapacity]; 
    }


    /**
     * No-Arg Constructor
     */
    public StringBag()
    {
    data = new String[10];
    numElements = 0;
    
    }

    /**
     * getCapacity method  gets the size of the bag 
     *                      
     * @return  returns the maximum size of the bag
     *           
     */
    public int getCapacity()
    {
      return data.length;  
    }

    /**
     * getSize method    gets the current number of items in the bag
     *                  
     * @return  returns the number of items in the bag
     *            
     */
    public int getSize()
    {
        return numElements;
    }

    /**
     * add method    this method adds a new fruit to the end of the bag
     *              
     * @param newElement new fruit name added into end of the bag 
     *                     
     */
    public void add(String newElement)
    {
        if (numElements == data.length)
            enlargeArray();

        // this version adds to the end of the array
        // have it maintain a..z order for extra credit
        data[numElements] = new String(newElement);
        numElements++;
    }

    /**
     * enlargeArray method  this method doubles the bag size capacity and then 
     * adds 1 to the bag size capacity 
     * 
     */
    private void enlargeArray()
    {
        String[] newArray = new String[data.length*2 + 1];

        for (int i = 0; i < data.length; i++)
            newArray[i] = new String(data[i]);

        data = newArray;
    }


    /**
     * exists method this method finds if a fruit name that the user inputs
     * is found in the bag 
     * @param target the user input for finding said item in the bag
     * @return   returns the user input for finding said item in the bag
     */
    public boolean exists(String target)
    {
        boolean found = false;
        int i = 0;

        while (!found && i < numElements)
            if (data[i].equalsIgnoreCase(target))
                found = true;
            else
                i++;

        return found;
    }

    /**
     * countOccurrences method    this method counts how many times the desired 
     * fruit name is found within the bag of items 
     * @param target   the user input for item that they want to be found 
     * @return   returns the user input for wanted item
    */
    public int countOccurrences(String target)
    {
       
        int numOccur = 0;
      for (int i = 0; i < numElements; i++)
          
           if (data[i].equalsIgnoreCase(target))
           { 
               numOccur++;
           }
    

        return numOccur;
    }

    /**
     * remove method  this method removes whatever item the user chooses
     * to delete from the bag
     *                
     * @param target   the user input for the deleted item
     *                 
     * @return   returns the user input for the deleted item
     *            
    */
    public boolean remove(String target)
    {
        boolean found = false;
        int i = 0;

        while (!found && i < numElements)
        {
            if (data[i].equalsIgnoreCase(target))
                found = true;
            else
                i++;
        }

        if (found)
        {
            data[i] = data[numElements-1];
            numElements--;
        }

        // have it maintain order for extra extra credit

        return found;
    }

    /**
     * iteratorPrototype method creates a copy of the data and
     * creates an iterator from the copied array
     * @return an iterator using ListerPrototype1 created from a copy of data
     */
    public ListerPrototype1 iteratorPrototype()
    {
        // since the data array is partially filled, create a copy
        // that is just a size of the number of elements filled
        String[] copyToReturn = new String[numElements];

        // loop through array and copy data to copy array
        for (int i = 0; i< numElements; i++)
            copyToReturn[i] = data[i];

        // instantiate a ListerProtoype1 using the copied array
        return new ListerPrototype1(copyToReturn);
    }
}