package javareviewcontinued;
/**
   Programmed by    Tony Gaddis
   modified by      Stephen Brower
   updated by       Linda Yang
   This program demonstrates the Rectangle class's
   constructor, getLength, getWidth, and
   getArea methods.
*/

import java.util.Random;

public class RectangleArrayDemo
{
    /**
     * The main method is the program's starting point.
     * @param args the command line arguments
     */
   public static void main(String[] args)
   {
      int i;
      double length, width;
      Random randomNumbers = new Random();
      // Create a list of Rectangles
      Rectangle[] listOfRectangles = new Rectangle[10];

      // generate rectangles
      for (i = 0; i < listOfRectangles.length; i++)
      {
          length = 1000*randomNumbers.nextDouble();
          width = 1000*randomNumbers.nextDouble();

          listOfRectangles[i] = new Rectangle(length, width);
      }

      // Display the rectangles
      for (i = 0; i < listOfRectangles.length; i++)
      {
          System.out.printf("%2d [%,7.1f, %,7.1f] = %,11.1f\n", i,
                    listOfRectangles[i].getLength(),
                    listOfRectangles[i].getWidth(),
                    listOfRectangles[i].getArea());
      }

   }
}
/*
Output (your results will vary):
 0 [  725.2,   836.9] =   606,884.1
 1 [  763.2,   426.0] =   325,144.5
 2 [  116.4,   910.6] =   105,964.1
 3 [  735.8,   622.7] =   458,210.6
 4 [  930.2,   627.9] =   584,053.7
 5 [  323.3,   116.3] =    37,600.6
 6 [  691.1,   141.9] =    98,076.9
 7 [  759.1,   259.2] =   196,794.8
 8 [  879.2,   694.1] =   610,255.1
 9 [  369.3,   949.0] =   350,425.1
*/