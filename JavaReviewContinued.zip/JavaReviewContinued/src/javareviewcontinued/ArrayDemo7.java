package javareviewcontinued;
import java.util.Scanner;

/**
 * Demonstrates the loading of an array of Strings from user
 * input checking to make sure the array is not full
 * Date Written:    11/27/2004
 * Date Modified:   11/19/2005
 *                  4/18/2007 - changed name and added comments
 * @author Stephen Brower
 */
public class ArrayDemo7
{
    /**
     * The main method is the program's starting point.
     * @param args the command line arguments
     */
    public static void main(String args[])
    {
        String name[] = new String[5], nameEntered;
        int n, i;

        Scanner input = new Scanner(System.in);

        System.out.print("Enter a name (xxx to exit): ");
        nameEntered = input.nextLine();

        // n is the number of elements USED in the array
        n = 0;

        // loop until user enters xxx or Array is full
        while ( !(nameEntered.equalsIgnoreCase("xxx")) && (n < name.length))
        {
            name[n] = nameEntered;
            n++;

            // if array is not full then ask user for a name
            if (n < name.length)
            {
                System.out.print("Enter a name (xxx to exit): ");
                nameEntered = input.nextLine();
            }
            else
            {
                System.out.println("\nArray is full!");
            }
        }

        if (n > 0)
        {
            System.out.println("\nNames Entered\n");

            // display header
            System.out.printf("%2s %s\n\n","#","Name");

            for (i=0; i<n; i++)
                System.out.printf("%2d %s\n",i,name[i]);
        }

    }
}


