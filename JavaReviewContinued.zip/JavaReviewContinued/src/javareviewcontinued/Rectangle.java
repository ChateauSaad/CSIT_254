package javareviewcontinued;

/**
 * Rectangle class
 * @author Concept by:  Tony Gaddis (et al) modified by Stephen Brower
 */

public class Rectangle
{
   private double length;
   private double width;

   /**
    * No-arg Constructor
    */

   public Rectangle()
   {
      length = 1.0;
      width = 1.0;
   }

   /**
    * Constructor
    * @param len value for length field
    * @param w value for width field
    */
   public Rectangle(double len, double w)
   {
      length = len;
      width = w;
   }

   /**
    * Constructor that receives a rectangle to copy for a new rectangle
    * @param object2 the rectangle being copied
    */
   public Rectangle(Rectangle object2)
   {
      length = object2.getLength();
      width = object2.getWidth();
   }


   /**
    * The setLength method accepts an argument
    * which is stored in the length field.
    * @param len value for length field
    */

   public void setLength(double len)
   {
      length = len;
   }

   /**
    * The setWidth method accepts an argument
    * which is stored in the width field.
    * @param w value for width field
    */

   public void setWidth(double w)
   {
      width = w;
   }

   /**
    * The set method accepts two arguments
    * which are stored in the length and width
    * fields.
    * @param len value for length field
    * @param w value for width field
    */

   public void set(double len, double w)
   {
      length = len;
      width = w;
   }

   /**
    * The getLength method returns the value
    * stored in the length field.
    * @return value from length field
    */

   public double getLength()
   {
      return length;
   }

   /**
    * The getWidth method returns the value
    * stored in the width field.
    * @return value from width field
    */

   public double getWidth()
   {
      return width;
   }

   /**
    * The getArea method returns the value of the
    * length field times the width field.
    * @return area based on length and width
    */

   public double getArea()
   {
      return length * width;
   }

   /**
    * toString method returns a String based on this Rectangle
    * @return String representation of this Rectangle
    */
   public String toString()
   {
       return "Rectangle L: " + length + " W: " + width;
   }

   /**
    * equals method used to compare this instance of Rectangle
    * to another Rectangle
    * @param otherRectangle another instance of Rectangle to compare to
    * @return boolean with result of comparison */
   public boolean equals(Rectangle otherRectangle)
   {
       boolean alike;

       if (length == otherRectangle.getLength() &&
               width == otherRectangle.getWidth())
           alike = true;
       else
           alike = false;

       return alike;
   }

   /**
    * copy method copies the object
    * @return a Rectangle object that is a copy of this Rectangle object
    */
   public Rectangle copy()
   {
      // Create a new Rectangle object and initialize it
      // with the same data held by the calling object.
      Rectangle copyObject = new Rectangle(length, width);

      // Return a reference to the new object.
      return copyObject;
   }

}
