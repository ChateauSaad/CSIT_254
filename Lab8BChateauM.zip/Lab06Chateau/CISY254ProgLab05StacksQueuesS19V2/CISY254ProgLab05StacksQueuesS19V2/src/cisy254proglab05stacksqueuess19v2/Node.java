package cisy254proglab05stacksqueuess19v2;

/**
 *
 * @author ??????
 */
public class Node<E> {
    
}
