
package project01chateaum;

//Author: Chateau Markos-Saad




public class Project01ChateauM {

 
    public static void main(String[] args) {
        // TODO code application logic here
    
        
     Soccer soccer = new Soccer(90,11,
             "Tottenham");
     
     Football football = new Football("Tom Brady"
             ,11, "Patriots" );
     
     
     
        System.out.println(soccer.toString());
        System.out.println("----------");
        System.out.println(football.toString());
    }
    
}
