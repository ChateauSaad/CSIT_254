/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package project01chateaum;

/**
 *
 * @author Chateau Markos-Saad
 */
public class Soccer extends Sport {

    private int gameLength;

    public Soccer(int newGameLength, int initialTeamSize,
            String initialTeamName) {
        super(initialTeamSize, initialTeamName);
        gameLength = newGameLength;
    }

    @Override
    public String toString() {
        return "Soccer: \nGame Length: " + gameLength + " minutes" + "\nTeam Size: "
                + super.getTeamSize() + "\nTeam Name: "
                + super.getTeamName();
    }

    public int getGameLength() {
        return gameLength;
    }

    public void setGameLength(int newGameLength) {
        gameLength = newGameLength;
    }

}
