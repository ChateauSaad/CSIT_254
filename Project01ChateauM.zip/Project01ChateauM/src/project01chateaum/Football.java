/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package project01chateaum;

/**
 *
 * @author Chateau Markos-Saad
 */
public class Football extends Sport {

    //insantiates the field for the best football player
    private String bestPlayer;

    /**
     * Constructor
     *
     * @param newBestPlayer the best football player
     * @param initialTeamSize the size of a football team
     * @param initialTeamName the name of a football team
     */
    public Football(String newBestPlayer, int initialTeamSize, String initialTeamName) {
        super(initialTeamSize, initialTeamName);
        bestPlayer = newBestPlayer;
    }

    /**
     * toString method: this method prints out best football player, football
     * team size, football team name, when called in the main
     *
     * @return returns best player, football team size, and football team name
     */
    @Override
    public String toString() {
        return "Football \nBest player: " + bestPlayer + "\nTeam Size: "
                + super.getTeamSize() + "\nTeam Name: " + super.getTeamName();
    }

    /**
     * getBestPlayer method: this method gets the best football player
     *
     * @return returns the best football player
     */
    public String getBestPlayer() {
        return bestPlayer;
    }

    /**
     * this method sets the best football player
     *
     * @param newBestPlayer the best football player
     */
    public void setBestPlayer(String newBestPlayer) {
        bestPlayer = newBestPlayer;
    }

}
