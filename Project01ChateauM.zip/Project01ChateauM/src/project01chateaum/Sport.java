
package project01chateaum;

/**
 *
 * @author Chateau
 */
public class Sport {
    private int teamSize;
    private String teamName;

    public Sport(int initialTeamSize, String initialTeamName) {
        teamSize = initialTeamSize;
        teamName = initialTeamName;
    }

    @Override
    public String toString() {
        return "Sport{" + "teamSize=" + teamSize + ", teamName=" +
                teamName + '}';
    }

    public int getTeamSize() {
        return teamSize;
    }

    public String getTeamName() {
        return teamName;
    }

    public void setTeamSize(int initialTeamSize) {
     teamSize = initialTeamSize;
    }

    public void setTeamName(String initialTeamName) {
        teamName = initialTeamName;
    }














}
