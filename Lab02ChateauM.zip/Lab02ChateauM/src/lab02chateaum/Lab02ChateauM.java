package lab02chateaum;

import java.util.Scanner;

/**
 *
 * @author Chateau Markos-Saad
 * 9/14/2023
 * This code takes the user's input for a Song Title, Artist of the song, 
 * and length of song in seconds, then it puts those values into an array.
 * Finally, it prints out an array of all the inputs. 
 */
public class Lab02ChateauM {

    public static void main(String[] args) {

        String songTitleEntered, artistEntered;
        int lengthEntered;

        Song[] mySongList = new Song[5];
        int n = 0;

        Scanner keyboard = new Scanner(System.in);

        System.out.print("Enter a song title (xxx to stop) for song " + n + ": ");
        songTitleEntered = keyboard.nextLine();

        while (!(songTitleEntered.equalsIgnoreCase("xxx"))
                && (n < mySongList.length)) {

            System.out.print("Enter artist for song " + n + ": ");
            artistEntered = keyboard.nextLine();

            System.out.print("Enter length in seconds for song " + n + ": ");
            lengthEntered = keyboard.nextInt();
            keyboard.nextLine();

            mySongList[n] = new Song(songTitleEntered,
                    artistEntered, lengthEntered);
            n++;

            System.out.print("Enter a song title (xxx to stop) for song "
                    + n + ": ");
            songTitleEntered = keyboard.nextLine();
        }

        if (n > 0) {
            System.out.printf("\n%-30s %-30s %3s\n",
                    "Song Title", "Artist", "Len");

            for (int i = 0; i < n; i++) {

                System.out.printf("%-30s %-30s %3s",
                        mySongList[i].getSongTitle(),
                         mySongList[i].getArtist(),
                        mySongList[i].getLengthInSeconds());
                System.out.println();
            }

        }
    }
}
