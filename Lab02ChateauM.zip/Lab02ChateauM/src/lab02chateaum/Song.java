package lab02chateaum;

/**
 *
 * @author Chateau M
 * Class Song creates private fields for 3 variables, constructor for variables,
 * along with setters and getters for each of the private fields. 
 */
public class Song {

    private String songTitle;   
    private String artist;
    private int lengthInSeconds;
    
/**
    Constructor
    * @param initialSongTitle the song title
    * @param initialArtist the name of the artist 
    * @param initialLengthInSeconds the Length of the song in seconds 
  */
    public Song(String initialSongTitle, String initialArtist, 
            int initialLengthInSeconds) {
        songTitle = initialSongTitle;
        artist = initialArtist;
        lengthInSeconds = initialLengthInSeconds;
    }

    /** 
     * This method gets the name of the song.
     * @return returns the name of the song.
     */
    public String getSongTitle() {
        return songTitle; 
    }
    /** 
     * This method gets the name of the artist. 
     * @return returns the name of the artist
     */
    
    
    public String getArtist() {
        return artist;
    }
    /**
     * This method gets the length of the song in seconds
     * @return returns length of song in seconds 
     */
    public int getLengthInSeconds() {
        return lengthInSeconds;
    }
    
    /** 
     * this method stores a value in the songTitle field
     * @param initialSongTitle the name of the Song Title
     */
    public void setSongTitle(String initialSongTitle) {
        songTitle = initialSongTitle; 
    }
    /**
     * this method stores a value in the artist field
     * @param initialArtist the name of the song artist
     */
    public void setArtist(String initialArtist) {
        artist = initialArtist;
    }
    /**
     * this method stores a value in LengthInSeconds field
     * 
     * @param initialLengthInSeconds the length of the song in seconds 
     */
    public void setLengthInSeconds(int initialLengthInSeconds) {
        lengthInSeconds = initialLengthInSeconds;
    }
    
    

}
