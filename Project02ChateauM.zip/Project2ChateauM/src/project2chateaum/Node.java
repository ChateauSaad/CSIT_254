package project2chateaum;

/**
 *
 * @author Chateau M
 */
public class Node<E> {

    private E data;
    private Node<E> next;
/**
 * constructor
 * @param initialData the initial item in the bag
 * @param initialNext the link to the pieces of the bag
 */
    public Node(E initialData, Node<E> initialNext) {
        data = initialData;
        next = initialNext;
    }
/**
 * get data method - this method gets the data in the bag
 * @return returns the item in the bag 
 */
    public E getData() {
        return data;
    }
/**
 * getNext method - this method gets the link for the items in the bag
 * @return returns the link for items in the bag 
 */
    public Node<E> getNext() {
        return next;
    }
/**
 * setData - this method sets the item in the bag
 * @param newData new item in the bag
 */
    public void setData(E newData) {
        data = newData;
    }
/**
 * setNext- this method sets the link for an item in the bag
 * @param newNext new link in the bag in between items 
 */
    public void setNext(Node<E> newNext) {
        next = newNext;
    }

}
