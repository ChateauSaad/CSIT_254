package project2chateaum;

/**
 *
 * @author Chateau
 */
public class Sport implements Comparable<Sport> {

    //instantiates the team size and team name
    private int teamSize;
    private String teamName;

    /**
     * Constructor
     *
     * @param initialTeamSize size of the team
     * @param initialTeamName name of the team
     */
    public Sport(int initialTeamSize, String initialTeamName) {
        teamSize = initialTeamSize;
        teamName = initialTeamName;
    }

    /**
     * getTeamSize method: this method gets the size of the team
     *
     * @return returns the size of the team
     */
    public int getTeamSize() {
        return teamSize;
    }

    /**
     * getTeamName method: this method gets the name of the team
     *
     * @return returns the name of the team
     */
    public String getTeamName() {
        return teamName;
    }

    /**
     * setTeamSize method: this method sets the size of the team
     *
     * @param initialTeamSize the size of the team
     */
    public void setTeamSize(int initialTeamSize) {
        teamSize = initialTeamSize;
    }

    /**
     * setTeamName method: this method sets the name of the team
     *
     * @param initialTeamName the name of the team
     */
    public void setTeamName(String initialTeamName) {
        teamName = initialTeamName;
    }

    /**
     * equals method - this method checks if 2 instances of sports are equal in
     * terms of name and team size
     *
     * @param obj object of sport (team size and team name)
     * @return return true or false based on if they are equal or not
     */
    @Override
    public boolean equals(Object obj) {
        if (!(obj instanceof Sport)) {
            throw new ClassCastException("A Sport Object Expected.");
        }

        Sport otherSport = (Sport) obj;  // cast the Object to a Car

        if (teamName.equalsIgnoreCase(otherSport.getTeamName())
                && teamSize == otherSport.getTeamSize()) {
            return true;
        } else {
            return false;
        }
    }

    /**
     * compareTo method - this method compares team size to organize the sizes
     * from smallest to largest in order of the bag
     *
     * @param anotherSport another set of team size and team name for sport
     * @return returns a -1 or 1 to create an order of team sizes
     * @throws ClassCastException
     */
    @Override
    public int compareTo(Sport anotherSport) throws ClassCastException {
        if (!(anotherSport instanceof Sport)) {
            throw new ClassCastException("A Sport Object .");
        }

        if (getTeamSize() < anotherSport.getTeamSize()) {
            return -1;
        } else if (getTeamSize() > anotherSport.getTeamSize()) {
            return 1;
        } else {
            return teamName.compareToIgnoreCase(anotherSport.getTeamName());
        }
    }

}
