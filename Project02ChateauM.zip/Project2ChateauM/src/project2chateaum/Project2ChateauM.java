package project2chateaum;

import java.util.Scanner;

public class Project2ChateauM {

    public static void main(String[] args) {
        Sport sportToTest;
        String userInput = null;
        String teamName = null;
        int teamSize;

        SinglyLinkedList<Sport> sportBag = new SinglyLinkedList<Sport>();

        Scanner keyboard = new Scanner(System.in);
        do {
            System.out.println("Bag of Sports Teams\n\n");
            System.out.println("A- Add 'Team Name' to bag");
            System.out.println("R- Remove ' Team Name' from bag");
            System.out.println("F- Find ' Team Name' in bag");
            System.out.println("D - Display contents of bag");
            System.out.println("X- Exit");
            System.out.print("Enter selection: ");
            userInput = keyboard.nextLine();

            switch (userInput.toUpperCase()) {
                case "A":
                    System.out.print("\nEnter a new team name: ");
                    teamName = keyboard.nextLine();
                    System.out.print("Enter a new number " + ""
                            + "for the team size: ");
                    teamSize = keyboard.nextInt();
                    keyboard.nextLine();
                    sportBag.add(new Sport(teamSize,
                            teamName));
                    System.out.println();
                    break;

                case "R":

                    System.out.print("Enter a name of a " + ""
                            + " Team to remove from the bag: ");
                    teamName = keyboard.nextLine();
                    System.out.print("Enter a team size to" + ""
                            + " remove from the bag: ");
                    teamSize = keyboard.nextInt();
                    keyboard.nextLine();
                    sportToTest = new Sport(teamSize,
                            teamName);
                    if (sportBag.remove(sportToTest)) {
                        System.out.println("\nWas able to remove "
                                + sportToTest.getTeamName() + " with "
                                + sportToTest.getTeamSize() + " players");
                    } else {
                        System.out.println("\nWasn't able to remove "
                                + sportToTest.getTeamName() + " with "
                                + sportToTest.getTeamSize() + " players");
                    }
                    break;
                case "F":

                    System.out.print("\nEnter a name of a team to "
                            + "find in the bag: ");
                    teamName = keyboard.nextLine();
                    System.out.print("Enter a number of passengers to " + ""
                            + " find from the bag: ");
                    teamSize = keyboard.nextInt();
                    keyboard.nextLine();
                    sportToTest = new Sport(teamSize,
                            teamName);
                    if (sportBag.exists(sportToTest)) {
                        System.out.println("\nWas able to find "
                                + sportToTest.getTeamName() + " with "
                                + sportToTest.getTeamSize() + " players");
                    } else {
                        System.out.println("\nSorry! unable to find "
                                + sportToTest.getTeamName() + " with "
                                + sportToTest.getTeamSize() + " players ");
                    }
                    break;
                case "D":
                    Lister<Sport> sportList = sportBag.iterator();
                    System.out.println("Sport Bag: ");
                    if (sportList.hasNext()) {
                        while (sportList.hasNext()) {
                            Sport sportDisplay = sportList.next();
                            System.out.printf(sportDisplay.getTeamName());
                            System.out.printf(" with "
                                    + sportDisplay.getTeamSize());
                            System.out.printf(" number of players ");
                            if (sportList.hasNext()) {
                                System.out.printf(", ");
                            }
                        }
                        System.out.printf("Size: " + sportBag.getSize()
                                + "\n\n");
                    } else {
                        System.out.printf("[--empty--]       \tSize: "
                                + sportBag.getSize() + "\n\n");
                    }
                    break;
                case "X":
                    break;
                default:
                    System.out.println("\nInvalid choice\n\n");

            }

        } while (!userInput.equalsIgnoreCase("X"));
    }
}
