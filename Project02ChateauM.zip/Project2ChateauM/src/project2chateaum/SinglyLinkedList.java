package project2chateaum;

/**
 *
 * @author Chateau M
 */
public class SinglyLinkedList<E extends Comparable<E>> {
    //declare private fields    

    private Node<E> head;
    private Node<E> tail;
    private int numElements;

    /**
     * No-Arg Constructor
     */
    public SinglyLinkedList() {
        head = null;
        tail = null;
        numElements = 0;
    }

    /**
     * Add method - this method adds new items of name and size into the sport
     * bag
     *
     * @param newElement new set of sport including team size and name
     */
    public void add(E newElement) {
        if (head == null) {
            head = new Node<E>(newElement, null);
        } else {
            if (newElement.compareTo(head.getData()) <= 0) {
                head = new Node<E>(newElement, head);
            } else {
                Node<E> previous = head;
                Node<E> cursor = head.getNext();
                while (cursor != null && newElement.compareTo(cursor.getData()) > 0) {
                    previous = cursor;
                    cursor = cursor.getNext();

                }

                Node<E> node = new Node<>(newElement, cursor);
                previous.setNext(node);
            }
        }
        numElements++;
    }

    /**
     * getSize method - this method gets the size of the bag
     *
     * @return returns size of the bag
     */
    public int getSize() {
        return numElements;
    }

    /**
     * exists method - this method finds if the targeted item exists within the
     * bag
     *
     * @param target the item being targeted for finding
     * @return returns the found item
     */
    public boolean exists(E target) {
        boolean found = false;
        Node<E> cursor = head;
        while (cursor != null && !found) {
            if (cursor.getData().equals(target)) {
                found = true;
            } else {
                cursor = cursor.getNext();
            }

        }
        return found;
    }

    /**
     * countOccurrences method - this method counts how many times the targeted
     * item appears
     *
     * @param target the item targeted to be found
     * @return returns the number of occurrences
     */
    public int countOccurrences(E target) {

        Node<E> cursor = head;
        int countOccurrences = 0;

        while (cursor != null) {

            if (cursor.getData().equals(target)) {
                countOccurrences++;
                cursor = cursor.getNext();
            } else {
                cursor = cursor.getNext();
            }

        }
        return countOccurrences;
    }

    /**
     * remove method - this method removes the targeted item
     *
     * @param target
     * @return found item
     */
    public boolean remove(E target) {
        Node<E> cursor = head, previous = null;
        boolean found = false;
        while (cursor != null && !found) {
            if (cursor.getData().equals(target)) {
                found = true;
            } else {
                previous = cursor;
                cursor = cursor.getNext();
            }
        }
        if (found && cursor != null) {
            if (previous == null) {
                head = head.getNext();
            } else {
                previous.setNext(cursor.getNext());
            }
            if (tail == cursor) {
                tail = previous;
            }
            numElements--;
        }
        return found;
    }

    /**
     * the iteratorPrototype method "copies" the linked list and passes the
     * copied linked list to a new Lister<E>
     *
     * @return a Lister<E> using a copy of the linked list
     */
    public Lister<E> iterator() {
        // declare variables
        Node headOfListToReturn; // beginning of new "copied" list
        Node cursorOfListToCopy; // active node of list to copy
        Node lastNodeOfListToReturn; // end of new "copied" list

        // establish the copied list
        headOfListToReturn = null;

        if (head != null) {
            // create the head of the new list
            headOfListToReturn = new Node(head.getData(), null);
            // use lastNodeOfListToReturn as a pointer to the last node in the copied list
            lastNodeOfListToReturn = headOfListToReturn;
            // use currentCursor as the pointer to the existing list
            cursorOfListToCopy = head.getNext();
            // if we have a node...
            while (cursorOfListToCopy != null) {
                // create a new node from the end of the new list
                lastNodeOfListToReturn.setNext(new Node(cursorOfListToCopy.getData(), null));
                // move lastNodeOfListToReturn to the new last node
                lastNodeOfListToReturn = lastNodeOfListToReturn.getNext();
                // move the cursorOfListToCopy to the next node
                cursorOfListToCopy = cursorOfListToCopy.getNext();
            }
        }

        return new Lister(headOfListToReturn);
    }

}
