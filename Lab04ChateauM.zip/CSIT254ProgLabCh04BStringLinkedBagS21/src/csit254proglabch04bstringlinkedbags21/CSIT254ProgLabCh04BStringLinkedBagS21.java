package csit254proglabch04bstringlinkedbags21;

/**
 * Prog Lab for Ch 4B String Linked Bag
 * @author Stephen T. Brower
 * @author Linda Yang
 */
public class CSIT254ProgLabCh04BStringLinkedBagS21 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        TestPartBStringLinkedBagBatchTesterV2.main(args);
    }
    
}
