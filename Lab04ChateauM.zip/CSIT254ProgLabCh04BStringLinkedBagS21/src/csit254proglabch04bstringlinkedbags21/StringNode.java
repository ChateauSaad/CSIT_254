package csit254proglabch04bstringlinkedbags21;

/**
 *
 * @author Chateau Markos-Saad
 */
public class StringNode {

    private String data;
    private StringNode link;

    /**
     * Constructor
     *
     * @param initialData the initial item in the bag
     * @param initialLink the initial link the bag
     */
    public StringNode(String initialData, StringNode initialLink) {
        data = initialData;
        link = initialLink;
    }

    /**
     * getData method - this method gets the item for the bag
     *
     * @return returns the item in the bag
     */
    public String getData() {
        return data;
    }

    /**
     * getLink method - this method gets the link in between items in the bag
     *
     * @return returns the link for the items in the bag
     */
    public StringNode getLink() {
        return link;
    }

    /**
     * setData method- this method sets the data for the bag
     *
     * @param newData the new item entered into the bag
     */
    public void setData(String newData) {
        data = newData;
    }

    /**
     * setLink method - this method sets the link for items in the bag
     *
     * @param newLink the new link for an item in the bag
     */
    public void setLink(StringNode newLink) {
        link = newLink;
    }

}
