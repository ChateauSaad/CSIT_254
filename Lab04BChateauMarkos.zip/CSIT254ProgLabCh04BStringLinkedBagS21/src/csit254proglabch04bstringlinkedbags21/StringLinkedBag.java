package csit254proglabch04bstringlinkedbags21;

/**
 *
 * @author Chateau Markos-Saad
 *
 */
public class StringLinkedBag 
{

    // declare fields here ( private )
    private StringNode head;
    private StringNode tail;
    private int numElements;

    /**
     * No Arg Constructor
     *
     */
    public StringLinkedBag() 
    {
        head = null;
        tail = null;
        numElements = 0;
    }

    // methods here - iteratorPrototype() is provided at the bottom
    /**
     * getSize method - this method gets the size of the bag
     *
     * @return returns the number of items in the bag
     */
    public int getSize() 
    {
        return numElements;
    }

    /**
     * add method - this method adds a new item to the baglist
     *
     * @param element the name of a single item inside the bag
     */
    public void add(String element)
    {
        if (tail == null)
        {
            head = new StringNode(element, null);
            tail = head;
        } else {
            tail.setLink(new StringNode(element, null));
            tail = tail.getLink();
        }
        numElements++;
    }

    /**
     * exists method - this method finds if the target item exists in the bag
     *
     * @param target the item being looked for in the bag
     * @return returns the target if found or not
     */
    public boolean exists(String target)
    {
        boolean found = false;
        StringNode cursor = head;
        while (cursor != null && !found)
        {
            if (cursor.getData().equalsIgnoreCase(target)) 
            {
                found = true;
            } else {
                cursor = cursor.getLink();
            }

        }
        return found;
    }

    /**
     * countOccurrences method - this method counts how many times the target
     * item was found in the bag
     *
     * @param target the item being looked for in the bag
     * @return returns the number of times the item was found
     */
    public int countOccurrences(String target) 
    {
      

        StringNode cursor = head;
        int countOccurrences = 0;
        
        while (cursor != null) {

            if (cursor.getData().equalsIgnoreCase(target)) 
            {
                countOccurrences++;
                  cursor = cursor.getLink();
            } 
            else 
            {
            cursor = cursor.getLink();
            }
          
        }
       return countOccurrences;
    }
    /**
     * remove method - this method removes the targeted item from the bag
     *  
     * @param target the targeted fruit in the bag
     * @return returns the targeted item found 
     */
    public boolean remove(String target)
    {
        StringNode cursor = head, previous = null;
        boolean found = false;
        while (cursor != null && !found)
        {
            if (cursor.getData().equalsIgnoreCase(target))
            {
                found = true;
            } 
            else 
            {
                previous = cursor;
                cursor = cursor.getLink();
            }
        }
        if (found && cursor != null) 
        {
            if (previous == null)
            {
                head = head.getLink();
            } else
            {
                previous.setLink(cursor.getLink());
            }
            if (tail == cursor) 
            {
                tail = previous;
            }
            numElements--;
        }
        return found;
    }

    /**
     * the iteratorPrototype method "copies" the linked list and passes the
     * copied linked list to a new ListerPrototype2
     *
     * @return a ListerPrototype2 using a copy of the linked list
     */
    public ListerPrototype2 iteratorPrototype() {
        // declare variables
        StringNode headOfListToReturn; // beginning of new "copied" list
        StringNode cursorOfListToCopy; // active node of list to copy
        StringNode lastNodeOfListToReturn; // end of new "copied" list

        // establish the copied list
        headOfListToReturn = null;

        if (head != null) 
        {
            // create the head of the new list
            headOfListToReturn = new StringNode(head.getData(), null);
            // use lastNodeOfListToReturn as a pointer to the last node in the copied list
            lastNodeOfListToReturn = headOfListToReturn;
            // use currentCursor as the pointer to the existing list
            cursorOfListToCopy = head.getLink();
            // if we have a node...
            while (cursorOfListToCopy != null)
            {
                // create a new node from the end of the new list
                lastNodeOfListToReturn.setLink(new StringNode(cursorOfListToCopy.getData(), null));
                // move lastNodeOfListToReturn to the new last node
                lastNodeOfListToReturn = lastNodeOfListToReturn.getLink();
                // move the cursorOfListToCopy to the next node
                cursorOfListToCopy = cursorOfListToCopy.getLink();
            }
        }

        return new ListerPrototype2(headOfListToReturn);
    }

}
