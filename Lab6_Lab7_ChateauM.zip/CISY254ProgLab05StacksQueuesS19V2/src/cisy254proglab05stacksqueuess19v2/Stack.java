package cisy254proglab05stacksqueuess19v2;

/**
 *
 * @author Chateau Markos-Saad
 */
public class Stack<E> {

    private Node<E> top;
    private int numElements;
/**
 * no - arg cconstructor 
 */
  public Stack() {
        
        top = null;
        numElements = 0;
    }
/**
 * push method - this method adds a new item to the top of the stack 
 * @param element instance of car  
 */
    public void push(E element) {
        top = new Node<E>(element, top);
        numElements++;
    }
    /**
     *  pop method - this method removes an item of car from the stack 
     * specifically from the top 
     * @return returns an item of car 
     * @throws EmptyStack throws an Empty Stack if there are no items in the 
     * stack. 
     */
    public E pop() 
            throws EmptyStack
    {
        E returnElement;
        if (top == null)
      throw new EmptyStack();
        else 
        {
            returnElement = top.getData();
            top = top.getNext();
                    numElements--;
                  
        }
       return returnElement;
    }
    /**
     * size method - this method returns the number of items in the stack 
     * @return returns the number of items in the stack 
     */
    public int size()
    {
       return numElements;
    }

}
