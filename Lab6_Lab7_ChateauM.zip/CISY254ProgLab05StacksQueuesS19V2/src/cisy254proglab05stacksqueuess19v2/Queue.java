package cisy254proglab05stacksqueuess19v2;

/**
 *
 * @author Chateau Markos-Saad
 */
public class Queue<E> {

    private Node<E> front;
    private Node<E> rear;
    private int numElements;

    /**
     * no- arg constructor
     */
    public Queue() {
        front = null;
        rear = null;
        numElements = 0;

    }

    /**
     * add method - this method adds a new item of car into the bag where the
     * first added item will be the first removed
     *
     * @param newElement new item of car
     */
    public void add(E newElement) {
        if (rear == null) {
            front = new Node<E>(newElement, null);
            rear = front;
        } else {
            rear.setNext(new Node<E>(newElement, null));
            rear = rear.getNext();
        }
        numElements++;
    }

    /**
     * remove method - this method removes the first item of car in the bag
     *
     * @return returns the item from the bag
     * @throws EmptyQueue throws an empty queue if there are no items in the bag
     */
    public E remove()
            throws EmptyQueue {
        E element;
        if (front == null) {
            throw new EmptyQueue();
        } else {
            element = front.getData();
            if (front != rear) {
                front = front.getNext();
            } else {
                front = null;
                rear = null;
            }
            numElements--;
        }
        return element;
    }

    /**
     * size method - this method will retur the number of items in the bag
     *
     * @return returns the number of items in the bag
     */
    public int size() {
        return numElements;
    }
}
