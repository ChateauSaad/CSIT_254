package lab08treespt1pt2sum18testers;

/**
 *
 * @author Linda Yang
 */
// note: add <E extends Comparable<E>> if you use recursive
//       method instructor wrote on board...hope that's
//       not news
public class BSTNode<E extends Comparable<E>> {

    E data;
    BSTNode<E> left;
    BSTNode<E> right;

    /**
     * constructor
     *
     * @param newData new item in tree
     * @param newLeft - pointer to the left in a tree
     * @param newRight - pointer to the right in a tree
     */
    public BSTNode(E newData, BSTNode<E> newLeft, BSTNode<E> newRight) {
        data = newData;
        left = newLeft;
        right = newRight;

    }

    /**
     * getData method - this method gets the item in a tree
     *
     * @return
     */
    public E getData() {
        return data;
    }

    /**
     * getLeft method - this method gets the left item in a tree
     *
     * @return returns the left item in a tree
     */
    public BSTNode getLeft() {
        return left;
    }

    /**
     * getRight method - this method gets the right item in a tree
     *
     * @return returns the a right item in a tree
     */
    public BSTNode getRight() {
        return right;
    }

    public E getRightmostData() {
        if (right == null) {
            return data;
        } else {
            return right.getRightmostData();
        }
    }

    /**
     * inorderPrint method - this method puts items in order to print
     */
    public void inorderPrint() {
        {
            if (left != null) {
                left.inorderPrint();
            }
            System.out.println(data);
            if (right != null) {
                right.inorderPrint();
            }
        }
    }

    public BSTNode<E> removeRightmost() {
        if (right == null) {
            return left;
        } else {
            right = right.removeRightmost();
            return this;

        }

    }

    /**
     * setData method - this method sets the item in a tree
     *
     * @param newData new piece of data to be examined in a tree
     */
    public void setData(E newData) {
        data = newData;
    }

    /**
     * setLeft method - this method sets the left item in a tree
     *
     * @param newLeft new left item in a tree
     */
    public void setLeft(BSTNode<E> newLeft) {
        left = newLeft;
    }

    /**
     * setRight method - this method sets the right item in a tree
     *
     * @param newRight
     */
    public void setRight(BSTNode<E> newRight) {
        right = newRight;
    }

}
