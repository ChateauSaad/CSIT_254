package lab08treespt1pt2sum18testers;

/**
 *
 * @author Linda Yang
 */
public class Tree<E extends Comparable<E>> {

    BSTNode root;
    int numItems;

    /**
     * no arg constructor
     */
    public Tree() {
        root = null;
        numItems = 0;
    }

    /**
     * add method - this method adds a new child to the tree
     *
     * @param element
     */
    public void add(E element) {

        if (root == null) {

            root = new BSTNode<E>(element, null, null);
        } else {

            BSTNode<E> cursor = root;
            boolean done = false;

            while (!done) {
                if (element.compareTo(cursor.getData()) < 1) {

                    if (cursor.getLeft() == null) {
                        cursor.setLeft(new BSTNode<E>(element,
                                null,
                                null));
                        done = true;

                    } else {
                        cursor = cursor.getLeft();
                    }

                } else {
                    if (cursor.getRight() == null) {
                    cursor.setRight(new BSTNode<E>(element,
                            null, null));
                    done = true;
                    } else {
                        cursor = cursor.getRight();

                    }
                }
            
        }
            numItems++;
    }
}

    

    public boolean remove(E element) {
        boolean found = false;
        BSTNode<E> cursor = root;
        BSTNode<E> parentOfCursor = null;

        while (cursor != null && !found) {
            if (cursor.getData().compareTo(element) == 0) {
                found = true;

            } else {
                parentOfCursor = cursor;
                if (element.compareTo(cursor.getData()) < 1) {
                    cursor = cursor.getLeft();
                } else {
                    cursor = cursor.getRight();

                }
            }
        }

        if (cursor == null) {
            found = false;
        } else if (cursor == root && cursor.getLeft() == null) {
            root = cursor.getRight();
        } else if (cursor != root && cursor.getLeft() == null) {
            if (cursor == parentOfCursor.getLeft()) {
                parentOfCursor.setLeft(cursor.getRight());
            } else {
                parentOfCursor.setRight(cursor.getRight());
            }
        } else {
            cursor.setData(cursor.getLeft().getRightmostData());
            cursor.setLeft(cursor.getLeft().removeRightmost());

        }

        return found;
    }

    /**
     * size method - this method returns the size of the tree
     *
     * @return returns the number of items in the tree
     */
    public int size() {
        return numItems;

    }

    /**
     * printTree method - this method displays all items in the tree in order
     */
    public void printTree() {
        if (root != null) {
            root.inorderPrint();
        }

    }

}
