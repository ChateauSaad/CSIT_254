package lab08treespt1pt2sum18testers;

/**
 *
 * @author Linda Yang
 */
public class Tree<E extends Comparable<E>> {

    BSTNode root;
    int numItems;
/**
 * no arg constructor 
 */
    public Tree() {
        root = null;
        numItems = 0;
    }
/** 
 * add method - this method adds a new child to the tree 
 * @param element 
 */
    public void add(E element) {

        if (root == null) {

            root = new BSTNode<E>(element, null, null);
        } else {

            BSTNode<E> cursor = root;
            boolean done = false;

            while (!done) {
                if (element.compareTo(cursor.getData()) < 1) {

                    if (cursor.getLeft() == null) {
                        cursor.setLeft(new BSTNode<E>(element,
                                null,
                                null));
                        done = true;
                    } else {
                        cursor = cursor.getLeft();
                    }

                }

                {
                    if (cursor.getRight() == null) {
                        cursor.setRight(new BSTNode<E>(element,
                                null, null));
                        done = true;
                    } else {
                        cursor = cursor.getRight();
                    }

                }

            }
        }
        numItems++;
    }
    /**
     * size method - this method returns the size of the tree 
     * @return returns the number of items in the tree 
     */
    public int size() {
        return numItems;

    }
    /**
     * printTree method - this method displays all items in the tree in order 
     */
    public void printTree() {
        if (root != null) {
            root.inorderPrint();
        }

    }

}
